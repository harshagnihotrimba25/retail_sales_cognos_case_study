# Retail Sales Analysis & Customer Segmentation using IBM Cognos Analytics

> **Project type:** Descriptive analytics  
> **Dataset:** Synthetic / randomly generated retail transactions (1,200 rows)  
> **Tools:** IBM Cognos Analytics, CSV, spreadsheet/data-preparation tools, GitHub  
> **Important note:** The dataset is fictional and generated for academic practice. The dashboard image in `screenshots/` is an **illustrative mockup**, not a genuine screenshot of a live IBM Cognos session. Replace it with your own Cognos screenshots after reproducing the steps.

## 1. Title – Project Topic

**Retail Sales Analysis and Customer Segmentation using IBM Cognos Analytics**

This project uses descriptive analytics to summarize sales performance by month, region, product category, product, and customer age group. The objective is to convert transaction-level data into clear visual summaries that can support business decisions.

## 2. Introduction

Retail businesses record transactions across many products, customers, and locations. A structured analysis helps managers understand what is selling, where revenue is generated, and which customer groups contribute to sales. IBM Cognos Analytics can connect to tabular data, prepare data for analysis, and present results through charts, reports, and dashboards.

This case study demonstrates a practical descriptive-analytics workflow with a fictional retail dataset. It is suitable as a learning project and GitHub portfolio example; the figures should not be interpreted as real company performance.

## 3. Problem Statement

A retail manager needs a concise view of business performance but has transaction-level records that are difficult to interpret manually. The project addresses these questions:

- How do sales change over the year?
- Which region contributes the most and least revenue?
- Which product categories and individual products perform best?
- How does sales contribution vary by customer age group?
- Which findings can inform promotions, stock planning, and customer-retention activities?

## 4. Data Discussion

The file `data/retail_sales_synthetic.csv` contains **1,200 fictional transaction records** covering January–December 2025.

| Field | Description |
|---|---|
| `Transaction_ID` | Unique order/transaction identifier |
| `Order_Date` | Date of the transaction |
| `Region` | Sales region: North, South, East, or West |
| `Customer_ID` | Fictional customer identifier |
| `Customer_Age` | Customer age in years |
| `Gender` | Customer gender field, including non-disclosed |
| `Product_Category` | Broad product grouping |
| `Product` | Product name |
| `Quantity` | Units purchased |
| `Unit_Price` | Price per unit before discount |
| `Discount_Rate` | Discount represented as a decimal |
| `Sales_Amount` | Transaction sales value after discount and synthetic seasonal adjustment |
| `Payment_Method` | Payment method used |

### Data preparation

- Checked the dataset structure and field types.
- Used a unique transaction ID for record-level identification.
- Converted `Order_Date` to a date field for monthly grouping.
- Treated `Sales_Amount` and `Quantity` as numeric measures.
- Grouped customers into age bands for a simple demographic comparison.
- Aggregated sales by month, region, category, product, and age group.

The data is generated for demonstration and does not represent actual customer information.

## 5. Method, Tools & Technologies Used

- **Methodology:** Descriptive analytics, aggregation, grouping, trend analysis, and visual comparison.
- **Primary BI tool:** IBM Cognos Analytics (data module, exploration/reporting, and dashboard capabilities where available in the installed version).
- **Data format:** CSV.
- **Visualizations:** Line chart, bar charts, and category comparisons.
- **Repository:** GitHub for sharing the README, dataset, charts, and project documentation.

No predictive model is built in this project. The focus is on describing observed patterns in the sample data rather than forecasting future results.

## 6. Workflow

1. **Import data** – Upload `retail_sales_synthetic.csv` into Cognos Analytics.
2. **Inspect fields** – Confirm dates, categories, identifiers, and numeric measures are assigned suitable data types.
3. **Prepare data** – Check missing values, duplicates, field formats, and any inconsistent labels.
4. **Create calculated fields if needed** – For example, `Sales Amount = Quantity × Unit Price × (1 − Discount Rate)` if reproducing the dataset without its seasonal adjustment. For this provided CSV, use the existing `Sales_Amount` field.
5. **Build visualizations** – Create monthly sales, sales by region, sales by category, top products, and age-group sales.
6. **Assemble dashboard** – Arrange KPI cards and charts on one dashboard page.
7. **Review and communicate** – Check labels, sorting, aggregation, and conclusions before sharing.

## 7. Procedure

### A. Import the CSV into Cognos Analytics
1. Open IBM Cognos Analytics and sign in to your workspace.
2. Select the option to upload or add a data file (wording can vary by Cognos version).
3. Upload `data/retail_sales_synthetic.csv`.
4. Open the resulting data asset and verify that `Order_Date` is recognized as a date and that `Sales_Amount`, `Quantity`, `Unit_Price`, and `Discount_Rate` are numeric.

### B. Prepare and validate
1. Review the column list and remove any unnecessary fields only if your analysis does not need them.
2. Check for missing values and duplicate `Transaction_ID` values.
3. Verify the currency/number formatting for sales measures.
4. Create a month grouping from `Order_Date` if Cognos does not automatically offer date hierarchy options.
5. Use `Sales_Amount` as the measure for the sales charts and `Transaction_ID` or row count for transaction volume.

### C. Create the visualizations
- **Monthly trend:** Line chart; month on the x-axis and sum of `Sales_Amount` on the y-axis.
- **Regional performance:** Bar chart; `Region` as category and sum of `Sales_Amount` as value.
- **Category mix:** Bar or pie chart; `Product_Category` and sum of `Sales_Amount`.
- **Top products:** Bar chart; `Product` and sum of `Sales_Amount`, sorted descending and filtered to the top products.
- **Customer age groups:** Bar chart; age band and sum of `Sales_Amount`.

### D. Build the dashboard and capture your own screenshots
1. Create a dashboard and add the charts.
2. Add KPI cards for total sales, transaction count, average transaction value, and total quantity.
3. Add filters for region, product category, and order date if available.
4. Give each chart a clear title and label.
5. Take screenshots of the actual Cognos workspace, data module, and finished dashboard after completing these steps. Save them under `screenshots/` and replace the illustrative mockup if you want the repository to show your own work.

**Screenshot integrity:** `screenshots/illustrative_cognos_dashboard_mockup.png` is a concept illustration only; it must not be presented as a real screenshot captured from IBM Cognos Analytics.

## 8. Results / Predictive Model

### Descriptive results

| KPI | Result |
|---|---:|
| Total sales | 476,975.26 |
| Number of transactions | 1,200 |
| Average transaction value | 397.48 |
| Total quantity sold | 3,558 |
| Highest-sales region | North |
| Highest-sales category | Electronics |
| Top product by sales | Laptop |
| Highest-sales month | February |

The charts in `visualizations/` are generated directly from the included synthetic dataset. Their totals and rankings may differ from any separate mockup image, which is illustrative and not data-linked.

### Visualizations

![Monthly sales trend](visualizations/monthly_sales_trend.png)

![Sales by region](visualizations/sales_by_region.png)

![Sales by category](visualizations/sales_by_category.png)

![Top products](visualizations/top_products.png)

![Sales by customer age group](visualizations/sales_by_age_group.png)

### Predictive model note

This is a **descriptive analytics** project, so no predictive model or forecast accuracy is claimed. A future extension could add time-series forecasting, but that would require a separate method, validation, and evaluation.

## 9. Insights (Observations)

- **Regional performance:** North is the highest-sales region in this generated sample, while East is the lowest-sales region. The difference can be used to guide further investigation rather than assuming the lower region is underperforming for a particular reason.
- **Product category:** Electronics contributes the greatest sales value among the categories in this sample.
- **Product-level contribution:** Laptop is the leading product by sales amount in the generated records.
- **Seasonality:** The monthly chart helps identify stronger and weaker periods; the generated data includes a modest November–December uplift, so this pattern is a feature of the synthetic data rather than evidence about a real retailer.
- **Customer age:** The age-group chart provides a high-level view of sales contribution. It does not establish causation or customer profitability.

## 10. Recommendations / Suggestions

1. **Plan stock using observed demand:** Review the strongest categories and products before setting replenishment quantities.
2. **Investigate regional gaps:** Compare pricing, availability, delivery performance, and marketing activity in lower-sales regions before allocating additional budget.
3. **Use time-based promotions carefully:** Test promotions during lower-sales months and measure whether they improve revenue without excessive discounting.
4. **Build customer segments responsibly:** Use age groups only as one descriptive dimension; combine them with purchase history and customer preferences where appropriate.
5. **Track dashboard KPIs regularly:** Monitor sales, transaction count, average transaction value, and quantity sold in a recurring reporting cycle.
6. **Validate with real data before decisions:** Replace the fictional dataset with approved business data before making operational or commercial decisions.

## Repository Structure

```text
retail-sales-cognos-case-study/
├── README.md
├── data/
│   └── retail_sales_synthetic.csv
├── screenshots/
│   └── illustrative_cognos_dashboard_mockup.png
└── visualizations/
    ├── monthly_sales_trend.png
    ├── sales_by_region.png
    ├── sales_by_category.png
    ├── top_products.png
    └── sales_by_age_group.png
```

## How to Use

1. Download or clone this repository.
2. Open `data/retail_sales_synthetic.csv` in a spreadsheet tool or upload it into IBM Cognos Analytics.
3. Recreate the charts using the workflow and procedure above.
4. Replace the illustrative screenshot with genuine screenshots of your own Cognos work.
5. Commit the project files to GitHub.

## Limitations

- The records and findings are synthetic and are intended for learning.
- The charts generated in Python are companion visuals; recreate them in Cognos to demonstrate your own Cognos workflow.
- Descriptive relationships do not prove causation and do not predict future results.
